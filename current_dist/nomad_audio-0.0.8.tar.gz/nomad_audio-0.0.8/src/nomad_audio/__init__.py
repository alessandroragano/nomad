from .nomad import Nomad
nomad = Nomad()